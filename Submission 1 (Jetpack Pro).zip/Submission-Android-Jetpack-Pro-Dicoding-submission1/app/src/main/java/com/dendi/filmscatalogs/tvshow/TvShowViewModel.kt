package com.dendi.filmscatalogs.tvshow

import androidx.lifecycle.ViewModel
import com.dendi.filmscatalogs.film.FilmEntity
import com.dendi.filmscatalogs.film.DataDummy

class TvShowViewModel: ViewModel() {
    fun getTvShow():List<FilmEntity> = DataDummy.generateDummyTvShow()
}