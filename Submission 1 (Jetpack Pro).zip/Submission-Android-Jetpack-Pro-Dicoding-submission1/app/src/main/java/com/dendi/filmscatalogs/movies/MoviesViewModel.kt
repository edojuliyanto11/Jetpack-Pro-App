package com.dendi.filmscatalogs.movies

import androidx.lifecycle.ViewModel
import com.dendi.filmscatalogs.film.FilmEntity
import com.dendi.filmscatalogs.film.DataDummy

class MoviesViewModel: ViewModel() {
    fun getMovies( ):List<FilmEntity> = DataDummy.generateDummyMovies()
}