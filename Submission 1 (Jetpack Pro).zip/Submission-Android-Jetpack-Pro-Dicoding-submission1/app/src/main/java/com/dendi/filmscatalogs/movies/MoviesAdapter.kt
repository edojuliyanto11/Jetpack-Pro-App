package com.dendi.filmscatalogs.movies

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dendi.filmscatalogs.R
import com.dendi.filmscatalogs.film.FilmEntity
import com.dendi.filmscatalogs.databinding.FilmsItemBinding
import com.dendi.filmscatalogs.detail.DetailActivity

class MoviesAdapter : RecyclerView.Adapter<MoviesAdapter.ContentViewHolder>() {
    private var listMovies = ArrayList<FilmEntity>()

    fun setMovies(movies: List<FilmEntity>?) {
        if (movies == null) return
        this.listMovies.clear()
        this.listMovies.addAll(movies)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContentViewHolder {
        val itemsMovies = FilmsItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ContentViewHolder(itemsMovies)
    }

    override fun onBindViewHolder(holder: ContentViewHolder, position: Int) {
        holder.bind(listMovies[position])

        holder.btnSave.setOnClickListener {
            Toast.makeText(
                it.context,
                "Saving " + listMovies[position].title + "....",
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.btnCopy.setOnClickListener {
            Toast.makeText(
                it.context,
                "Copied " + listMovies[position].title,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun getItemCount(): Int {
        return listMovies.size
    }

    inner class ContentViewHolder(private val binding: FilmsItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var btnSave: Button = itemView.findViewById(R.id.save_main)
        var btnCopy: Button = itemView.findViewById(R.id.my_button)
        fun bind(movies: FilmEntity) {
            binding.titleItem.text = movies.title
            binding.dateItem.text = movies.dateRelease
            Glide.with(itemView.context)
                .load(movies.images)
                .into(binding.imageItem)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra(DetailActivity.EXTRA_DATA, movies)
                intent.putExtra(DetailActivity.EXTRA_TYPE, "movies")
                itemView.context.startActivity(intent)
            }
        }
    }
}