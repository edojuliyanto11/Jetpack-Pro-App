## Instumental Testing Aplikasi Submission dicoding

* Menampilkan Tombol Tab
    1. Memastikan Tab dalam keadaan tampil
    2. Memberikan tindakan Swipe ke kiri pada Tab
    3. Memberikan tindakan Swipe ke kanan pada Tab
    4. Memberikan tindakan klik pada Tab dengan nilai "Tv Show"
    5. Memberikan tindakan klik pada Tab dengan nilai "Movies"

* Menampilkan data Movies
    1. memastikan rv_movies dalam keadaan tampil
    2. gulir rv_movies ke posisi terakhir
    
* Menampilkan data detail Movies
    1. Memberikan tindakan klik pada data pertama pada rv_movies
    2. Memastikan TextView untuk title_detail tampil sesuai dengan yang diharapkan.
    3. Memastikan TextView untuk date_release tampil sesuai dengan yang diharapkan.
    4. Memastikan TextView untuk genre_duration tampil sesuai dengan yang diharapkan.
    5. Memastikan TextView untuk overview tampil sesuai dengan yang diharapkan.
    6. Memastikan ImageView untuk images_detail dapat ditampilkan.
    7. Memastikan share icon dapat ditampilkan.

* Menampilkan data Tv Show
    1. memastikan rv_tv_show dalam keadaan tampil
    2. gulir rv_tv_show ke posisi terakhir
 
* Menampilkan data detail Tv Show
    1. Klik TabLayout dengan teks tv show
    2. Memberikan tindakan klik pada data pertama pada rv_tv_show
    3. Memastikan TextView untuk title_detail tampil sesuai dengan yang diharapkan.
    4. Memastikan TextView untuk date_release tampil sesuai dengan yang diharapkan.
    5. Memastikan TextView untuk genre_duration tampil sesuai dengan yang diharapkan.
    6. Memastikan TextView untuk overview tampil sesuai dengan yang diharapkan.
    7. Memastikan ImageView untuk images_detail dapat ditampilkan.
    8. Memastikan share icon dapat ditampilkan.