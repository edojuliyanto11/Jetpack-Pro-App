## Unit Testing Aplikasi Submission dicoding 

* MoviesViewModelTest
    - Memuat Movies :
        1. Memastikan data Movies tidak null.
        2. Memastikan jumlah data Movies sesuai dengan yang diharapkan.
        
* TvShowViewModelTest
    - Memuat Tv Show :
        1. Memastikan data Tv Show tidak null.
        2. Memastikan jumlah data Tv Show sesuai dengan yang diharapkan.
        
* DetailActivityViewModel
    - Memuat data pilihan :
        1. Memastikan data pilihan tidak null.
        2. Memastikan data pilihan sesuai dengan yang diharapkan.